package com.example.ecommerceapp.fragments.loginRegister

import androidx.fragment.app.Fragment
import com.example.ecommerceapp.R

class AccountOptionsFragment: Fragment(R.layout.fragment_account_options) {
}