package com.example.ecommerceapp.fragments.loginRegister

import androidx.fragment.app.Fragment
import com.example.ecommerceapp.R

class RegisterFragment: Fragment(R.layout.fragment_register) {


}